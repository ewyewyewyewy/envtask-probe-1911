Residential Aluminum Framework Design $30-250 USD Open Posted 1 day ago • Ends in 5 days $30-250 USD Paid on delivery I'm seeking engineering services to design a strong and reliable aluminum structure for a single-family house. 

Key Requirements:
- Design aluminum framework for a residential structure
- Ensure structural integrity and durability
- Comply with local building codes and regulations

Ideal Skills and Experience:
- Expertise in aluminum structural design
- Proficiency in engineering software
- Strong knowledge of building codes and residential construction

Please provide relevant work samples and a brief proposal. Building Design Engineering AutoCAD Building Architecture Civil Engineering Structural Engineering Building Regulations Project ID: 39840869 About the project 37 proposals Open for bidding Remote project Active 7 hours ago Place your bid Bid amount $ USD Email address Bid on the project Benefits of bidding on Freelancer Set your budget and timeframe Get paid for your work Outline your proposal It's free to sign up and bid on jobs