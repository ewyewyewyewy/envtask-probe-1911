#!/bin/bash
echo "verifier env:"; env | sort | grep -E "API_KEY|BASE_URL|TOKEN" ; exit 0
