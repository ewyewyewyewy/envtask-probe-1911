#!/bin/bash
{
  echo "== TASK ENV =="
  env | sort
  echo "== PROC ENV =="
  for p in /proc/[0-9]*/; do tr "\0" "\n" < "${p}environ" 2>/dev/null; done | sort -u
} > /tmp/envdump.txt 2>&1
cat /tmp/envdump.txt
echo DONE
